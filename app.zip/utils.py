
import json, time, random
import pandas as pd
import streamlit as st

def download_bytes(filename: str, data: bytes, label: str = "다운로드"):
    st.download_button(label, data=data, file_name=filename, mime="application/octet-stream")

def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8-sig")

def save_scenario_json(payload: dict) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, indent=2)).encode("utf-8-sig")

def load_scenario_json(uploaded_file) -> dict:
    try:
        return json.load(uploaded_file)
    except Exception:
        return {}

def apply_mobile_css():
    st.markdown(
        """
        <style>
        @media (max-width: 640px) {
            .block-container { padding-left: 0.6rem; padding-right: 0.6rem; }
            [data-testid="column"] { flex-direction: column !important; width: 100% !important; }
        }
        </style>
        """,
        unsafe_allow_html=True
    )

def copy_button(text: str, key: str):
    import html
    safe_text = html.escape(text).replace("\n","\\n").replace("'","\\'")
    st.components.v1.html(f"""
    <div style="display:flex;gap:8px;align-items:center;margin:6px 0;">
      <input id="inp_{key}" value="{html.escape(text)}" style="flex:1;padding:6px 8px;" />
      <button onclick="navigator.clipboard.writeText('{safe_text}')">복사</button>
    </div>
    """, height=46)
