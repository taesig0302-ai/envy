
# ENVY v26 Final

이 빌드는 v23 앵커 기준으로 남은 5~7% 디테일을 채운 안정판입니다.

## 포함
- 데이터랩: Top100 + 예외처리(재시도/캐시), 비교 그래프(상승=초록/하락=빨강), CSV
- 상품명 생성기: 규칙/OPENAI 모드, 프롬프트 템플릿 입력, A/B 테스트, 복사 버튼(JS)
- 11번가: 요약 카드 + 링크 아웃, CSV, 캐시 fallback
- UX: 시나리오 JSON 저장/불러오기 + **자동 주입**, 모바일 반응형, 다크/라이트 호환
- 사이드바 계산기: on_cost/on_sale, 수수료 차감/가산

## 실행
pip install -r requirements.txt
streamlit run app_v26.py
