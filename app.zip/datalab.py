
import time, math
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from utils import to_csv_bytes

def _mock_fetch(category: str, period: str):
    # 모의 API: 일부 카테고리는 누락/지연을 발생시켜 예외처리 테스트
    if "누락" in category:
        raise ValueError("API 응답 누락")
    n=20
    return pd.DataFrame({
        "keyword":[f"{category}-{i}" for i in range(1,n+1)],
        "curr":[max(1,100-i*2) for i in range(n)],
        "prev":[max(1,90-i*2) for i in range(n)],
    })

def robust_fetch(category: str, period: str, retries=2, delay=0.4):
    last_err=None
    for t in range(retries+1):
        try:
            return _mock_fetch(category, period)
        except Exception as e:
            last_err=e
            time.sleep(delay*(t+1))
    raise last_err

def render():
    st.subheader("데이터랩 Top100 + 비교 그래프")
    cat = st.text_input("카테고리", value="식품")
    period = st.selectbox("기간", ["최근7일","최근30일","최근90일"], index=1)

    # API 호출 + 예외처리
    try:
        df = robust_fetch(cat, period, retries=2)
    except Exception as e:
        st.warning(f"API 응답 누락/오류: {e}. 캐시/대체값으로 표시합니다.")
        df = pd.DataFrame({
            "keyword":[f"{cat}-cache-{i}" for i in range(1,21)],
            "curr":[50]*20, "prev":[48]*20
        })

    df["diff"] = df["curr"] - df["prev"]
    df["pct"] = (df["diff"] / df["prev"].replace(0,1)) * 100.0

    st.dataframe(df.head(100), use_container_width=True)

    st.write("기간 비교 그래프 (상승=초록, 하락=빨강)")
    topn = st.slider("표시 개수", 5, min(30, len(df)), 15)
    show = df.head(topn).copy()
    colors = ["green" if x>=0 else "red" for x in show["diff"]]

    fig, ax = plt.subplots(figsize=(8,4))
    ax.bar(show["keyword"], show["diff"], color=colors)
    ax.set_ylabel("증감")
    ax.set_xticklabels(show["keyword"], rotation=45, ha="right")
    st.pyplot(fig, clear_figure=True)

    st.download_button("CSV 내보내기", data=to_csv_bytes(df), file_name="datalab_top100.csv", mime="text/csv")
