
import pandas as pd
import streamlit as st
from utils import to_csv_bytes

def _summary(df: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({
        "count":[len(df)],
        "avg_price":[df["price"].mean() if "price" in df else None],
        "sum_sales":[df["sales"].sum() if "sales" in df else None]
    })

def render():
    st.subheader("11번가 요약")
    url = st.text_input("리스트/검색 URL (옵션)", placeholder="https://www.11st.co.kr/...")
    st.caption("모바일 embed는 정책상 제외. 대신 요약 카드 + 링크 아웃 제공.")

    use_cache = st.toggle("캐시(샘플) 사용", value=True)
    if use_cache:
        df = pd.DataFrame({
            "title": [f"샘플상품{i}" for i in range(1,11)],
            "price": [i*1000 for i in range(10)],
            "sales": [i*3 for i in range(10)],
            "link": [url or "https://www.11st.co.kr/"]*10
        })
    else:
        up = st.file_uploader("크롤 결과 CSV 업로드", type=["csv"])
        if up is None:
            st.info("CSV 업로드 또는 캐시 사용을 선택하세요.")
            return
        df = pd.read_csv(up)

    # 카드 렌더
    for _, r in df.iterrows():
        st.markdown(f"**{r.get('title','')}**\n\n- 가격: {r.get('price','-')}\n- 판매량: {r.get('sales','-')}\n- 링크: {r.get('link','-')}\n")

    st.write("요약표")
    st.dataframe(_summary(df))

    st.download_button("CSV 다운로드", data=to_csv_bytes(df), file_name="11st_list.csv", mime="text/csv")
