
import streamlit as st
from calculators import MarginInputs, solve_sale
from utils import download_bytes, save_scenario_json, load_scenario_json, apply_mobile_css
import datalab, namegen, elevenst

st.set_page_config(page_title="ENVY v26 Final", page_icon="✅", layout="wide")

st.title("✅ ENVY v26 • Final")
st.caption("데이터랩(예외처리) • 상품명 생성기(A/B·복사·프롬프트) • 11번가(요약·캐시) • 시나리오 저장/불러오기 • 환율/마진 계산기")

apply_mobile_css()

# Sidebar calculator
with st.sidebar:
    st.header("환율/마진 계산기")
    mode = st.radio("모드", ["로켓그로스","해외구매대행"], horizontal=True)
    ex = st.number_input("환율 CNY→KRW", 0.0, 10000.0, 190.0, 0.5)
    card = st.number_input("카드/PG(%)", 0.0, 100.0, 4.0, 0.1)
    market = st.number_input("마켓(%)", 0.0, 100.0, 14.0, 0.1)
    target = st.number_input("목표마진(%)", 0.0, 100.0, 10.0, 0.1)
    basis = st.selectbox("마진 기준", ["on_cost","on_sale"], index=0)
    fee_mode = st.selectbox("수수료 처리", ["deduct_from_payout","add_on_top"], index=0)

    if mode=="로켓그로스":
        cny = st.number_input("상품원가(CNY)", 0.0, 1e9, 830.0, 1.0)
        total = 0.0
    else:
        cny = 0.0
        total = st.number_input("총 원가(KRW)", 0.0, 1e12, 250000.0, 100.0)
    domestic = st.number_input("국내배송/창고", 0.0, 1e9, 0.0, 100.0)
    intl = st.number_input("국제배송", 0.0, 1e9, 0.0, 100.0)
    pack = st.number_input("포장비", 0.0, 1e9, 0.0, 100.0)
    other = st.number_input("기타비용", 0.0, 1e9, 0.0, 100.0)

    mi = MarginInputs(
        exchange_rate=ex, product_cost_cny=cny, total_cost_krw=total,
        domestic_ship=domestic, intl_ship=intl, packaging=pack, other=other,
        card_fee_pct=card, market_fee_pct=market, target_margin_pct=target,
        basis=basis, fee_mode=fee_mode, mode="rocket" if mode=="로켓그로스" else "buying"
    )
    res = solve_sale(mi)
    st.metric("권장 판매가", f"{res['sale_price']:,.0f} KRW")
    st.metric("순이익", f"{res['net_profit']:,.0f} KRW")
    st.caption(f"순마진(판매가): {res['net_margin_on_sale']:.2f}% • 순마진(원가): {res['net_margin_on_cost']:.2f}%")

tab1, tab2, tab3, tab4 = st.tabs(["데이터랩","상품명 생성기","11번가","시나리오 저장/불러오기"])
with tab1: datalab.render()
with tab2: namegen.render()
with tab3: elevenst.render()

with tab4:
    st.subheader("시나리오 저장/불러오기 (JSON)")
    if st.button("현재 설정 저장"):
        payload = dict(margin_inputs=mi.__dict__)
        download_bytes("envy_v26_scenario.json", save_scenario_json(payload), "JSON 다운로드")
    up = st.file_uploader("JSON 불러오기", type=["json"])
    if up is not None:
        loaded = load_scenario_json(up)
        st.write("불러온 시나리오:", loaded)
        # 자동 주입
        try:
            vals = loaded.get("margin_inputs", {})
            for k,v in vals.items():
                st.session_state[k]=v
            st.success("사이드바 입력에 자동 반영했습니다. 값 확인 후 필요시 수정하세요.")
        except Exception:
            st.warning("자동 반영 실패. 형식을 확인하세요.")
