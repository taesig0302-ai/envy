
from dataclasses import dataclass
from typing import Literal, Dict

@dataclass
class MarginInputs:
    exchange_rate: float = 190.0
    product_cost_cny: float = 0.0
    total_cost_krw: float = 0.0
    domestic_ship: float = 0.0
    intl_ship: float = 0.0
    packaging: float = 0.0
    other: float = 0.0
    card_fee_pct: float = 4.0
    market_fee_pct: float = 14.0
    target_margin_pct: float = 10.0
    basis: Literal["on_cost","on_sale"] = "on_cost"
    fee_mode: Literal["deduct_from_payout","add_on_top"] = "deduct_from_payout"
    mode: Literal["rocket","buying"] = "rocket"

def pct(x): return x/100.0

def aggregate_cost_krw(mi: MarginInputs) -> float:
    base = mi.product_cost_cny * mi.exchange_rate if mi.mode=="rocket" else mi.total_cost_krw
    return max(0.0, base + mi.domestic_ship + mi.intl_ship + mi.packaging + mi.other)

def solve_sale(mi: MarginInputs) -> Dict[str,float]:
    c = aggregate_cost_krw(mi)
    cf, mf, tm = pct(mi.card_fee_pct), pct(mi.market_fee_pct), pct(mi.target_margin_pct)
    if mi.fee_mode=="deduct_from_payout":
        if mi.basis=="on_cost":
            denom = (1 - cf - mf)
            P = (c*(1+tm))/max(1e-9, denom)
        else:
            denom = (1 - cf - mf - tm)
            P = c/max(1e-9, denom)
    else:
        if mi.basis=="on_cost":
            denom=(1-cf-mf); P=(c*(1+tm))/max(1e-9, denom)
        else:
            denom=(1-cf-mf-tm); P=c/max(1e-9, denom)
    revenue = P*(1-cf-mf)
    fees = P-revenue
    profit = revenue - c
    on_sale = (profit/P*100) if P>0 else 0.0
    on_cost = (profit/c*100) if c>0 else 0.0
    return dict(sale_price=P,revenue_after_fees=revenue,fees_total=fees,net_profit=profit,cost_total=c,net_margin_on_sale=on_sale,net_margin_on_cost=on_cost)
