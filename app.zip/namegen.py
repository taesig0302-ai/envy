
import os, random
import streamlit as st
from utils import copy_button

RULES = {
    "prefix": ["[Korea]", "[Official]", "[New]"],
    "joiner": [" | ", " · ", " — "],
    "suffix": ["FastShip", "HotDeal", "2025"]
}

def rule_based(brand:str, base:str, kws:list[str]) -> list[str]:
    names = []
    for _ in range(5):
        pref = random.choice(RULES["prefix"])
        suf = random.choice(RULES["suffix"])
        join = random.choice(RULES["joiner"])
        core = f"{brand}{join}{base} {', '.join(kws[:2])}"
        names.append(f"{pref} {core} {suf}")
    return names

def render():
    st.subheader("상품명 생성기 (규칙 기반 + OpenAI 모드)")

    brand = st.text_input("브랜드", value="envy")
    base = st.text_input("베이스(핵심 키워드)", value="K-coffee mix")
    keywords = st.text_input("연관키워드(쉼표로 구분)", value="Maxim, Kanu, Korea")
    badwords = st.text_input("금칙어(쉼표로 구분)", value="copy, fake, replica")
    limit = st.slider("글자수 제한", 20, 120, 80)

    mode = st.radio("모드", ["규칙 기반","OpenAI API"], horizontal=True)
    tmpl = st.text_area("OpenAI 프롬프트 템플릿", value="브랜드: {brand}\n핵심: {base}\n키워드: {keywords}\n금칙어: {bans}\n길이제한: {limit}\n조건에 맞는 상품명 5개.", height=120)

    def filter_and_trim(cands:list[str]) -> list[str]:
        bans = {w.strip().lower() for w in badwords.split(",") if w.strip()}
        out=[]
        for t in cands:
            t2 = " ".join(t.split())
            if any(b in t2.lower() for b in bans): 
                continue
            if len(t2)>limit: t2=t2[:limit]
            out.append(t2)
        return out

    if st.button("생성"):
        kws=[k.strip() for k in keywords.split(",") if k.strip()]
        if mode=="규칙 기반":
            cands = rule_based(brand, base, kws)
        else:
            key = os.getenv("OPENAI_API_KEY","")
            # 실제 호출 대신 템플릿을 미리 보이도록 하고, 키가 있으면 규칙 기반+템플릿 시드 가중치로 대체
            _ = tmpl.format(brand=brand, base=base, keywords=", ".join(kws), bans=badwords, limit=limit)
            if not key:
                st.warning("OPENAI_API_KEY가 없어 규칙 기반으로 대체합니다.")
            cands = rule_based(brand, base, kws)
        cands = filter_and_trim(cands)
        st.session_state["name_cands"]=cands

    # A/B 테스트
    st.markdown("---")
    st.write("**A/B 테스트 모드** — 두 세트 생성 후 투표")
    cols = st.columns(2)
    for i in range(2):
        with cols[i]:
            if st.button(f"세트 {i+1} 생성", key=f"ab{i}"):
                kws=[k.strip() for k in keywords.split(",") if k.strip()]
                cands = filter_and_trim(rule_based(brand, base, kws))
                st.session_state[f"ab_{i}"]=cands
            cands = st.session_state.get(f"ab_{i}", [])
            for idx, t in enumerate(cands):
                st.write(f"{idx+1}. {t}")
                copy_button(t, key=f"ab_{i}_{idx}")

    st.markdown("---")
    st.write("**생성 결과**")
    for idx, t in enumerate(st.session_state.get("name_cands", [])):
        st.write(f"{idx+1}. {t}")
        copy_button(t, key=f"cand_{idx}")
